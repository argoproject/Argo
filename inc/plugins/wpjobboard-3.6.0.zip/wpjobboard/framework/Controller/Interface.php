<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author greg
 */
interface Daq_Controller_Interface {
    //put your code here
}
?>
