<?php
/**
 * Description of JobType
 *
 * @author greg
 * @package
 */

class Wpjb_Model_PromoCode extends Daq_Db_OrmAbstract
{
    protected $_name = "wpjb_promo_code";

    protected function _init()
    {

    }
}

?>