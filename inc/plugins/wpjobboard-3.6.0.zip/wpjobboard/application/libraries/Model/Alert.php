<?php
/**
 * Description of Alert
 *
 * @author greg
 * @package 
 */

class Wpjb_Model_Alert extends Daq_Db_OrmAbstract
{
    protected $_name = "wpjb_alert";

    protected function _init()
    {
        
    }
}

?>