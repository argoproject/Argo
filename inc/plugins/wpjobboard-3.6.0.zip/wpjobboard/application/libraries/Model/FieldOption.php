<?php
/**
 * Description of FieldOption
 *
 * @author greg
 * @package 
 */

class Wpjb_Model_FieldOption extends Daq_Db_OrmAbstract
{
    protected $_name = "wpjb_field_option";

    public function _init()
    {

    }
}

?>