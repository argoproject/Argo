<?php
/**
 * Description of Seal
 *
 * @author greg
 * @package 
 */

class Wpjb_Module_Admin_Seal extends Wpjb_Controller_Admin
{
    public function indexAction()
    {
        
    }
}

?>