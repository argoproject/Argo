=== Argo Links ===
Contributors: Project Argo
Tags: links, argo, argo-links 
Requires at least: Only tested with 3.3.1
Tested up to: 3.3.1
Stable tag: 0.01

* NOTE: The plugin has been verified to work in WordPress 3.3.1. It is no longer under active development.
